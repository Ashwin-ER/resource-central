# Contributing

Thank you for watching my videos and reviewing code! If you find a bug, I'll gladly review
your PR. Please fork the repo first. 

I know there are a few different ways to code these algos. I'd like to avoid large changes 
and shifts in logic so the code stays as close as possible to the videos. Thanks!
