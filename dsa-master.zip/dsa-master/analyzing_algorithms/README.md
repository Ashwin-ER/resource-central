## Analyzing Algorithms

* [Playlist](https://www.youtube.com/playlist?list=PL9xmBV_5YoZMxejjIyFHWa-4nKg6sdoIv)
* Videos: [Intro](https://youtu.be/2_Ud0TESsa0) | [Asymptotic Notation](https://youtu.be/u8AprTUkJjM) | [Big-O Notation](https://youtu.be/__vX2sjlpXU)

```python
 ❯ python intro.py
[None, -1, 0, 0, 1, 2, 4, 5, 7, 8, 13, 20, 21, 22, 29, 67, 72, 99, 123]
[None, 1, 2, 3, 9]
```
